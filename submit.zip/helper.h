#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

int getLineLength(char *line);
char* getCurrentTime();
void removeTrailingNewLine(char* line);